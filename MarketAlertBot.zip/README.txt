# MarketAlertBot - Configurazione Rapida

## ✅ Cosa fare:

1. Carica tutti questi file su GitHub (o direttamente su Render se usi Deploy from Zip)
2. Imposta le variabili ambiente:
   - TELEGRAM_TOKEN = il tuo token del bot
   - CHAT_ID = il tuo chat_id Telegram
3. Avvia il deploy (Render o altra piattaforma Python)

Il bot:
- Invia un messaggio alle 08:30 con le notizie economiche
- Ogni 1 minuto controlla e invia un aggiornamento

⏱️ Funziona in loop continuo. Nessun intervento manuale richiesto.